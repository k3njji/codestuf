#include<stdio.h>

int main()
{
	
	int x, i;
	x=1;
	
	for(i=0; i<x; i++){
		int a[1000];
		int n;
		int e[1000];
		int count=0;
		scanf("%d", &n);
		for(int j=0; j<n; j++){
			int a[j];
			scanf("%d", &a[j]);
		}
		scanf("%d", &e);
		for(int k=0; k<e; k++){
			scanf("%d", &e[k]);
		}
		for(int z=0; z<n; z++){
			while(a[z]=a[z])
			count++
		}
	}
	
}
